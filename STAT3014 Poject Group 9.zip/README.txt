The cleanedData.csv file can be created using the code in data_cleaning.Rmd
The code in 'Project Final.Rmd' uses the data from 'cleanedData.csv'.